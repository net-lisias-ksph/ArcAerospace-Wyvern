# ArcAerospace-Wyvern
A Stock-alike Crew Dragon Capsule for Kerbal Space Program

Arc Aerospace parts pack by Jon Ross (https://zlsadesign.com/)
	(updated & modified by Stone Blue, with zlsa's permission)

License: CC-BY 4.0 International: https://creativecommons.org/licenses/by/4.0/

Fly safe!
